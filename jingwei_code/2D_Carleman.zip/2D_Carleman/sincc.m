function y = sincc(x)

y = sin(x+eps)./(x+eps);