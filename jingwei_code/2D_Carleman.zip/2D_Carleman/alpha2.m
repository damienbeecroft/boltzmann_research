function y = alpha2(s,R,L)

y = 2*R*sincc(pi/L*R*s);